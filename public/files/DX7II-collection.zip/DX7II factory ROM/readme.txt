This is the original factory cartridge that came with the DX7II D/FD, in case yours got lost.

Performances note:

"DX7II factory bank 1 perf" uses voices "bank 1 1-32" and "bank 1 33-64" in the internal memory.

"DX7II factory bank 2 perf" uses both "bank 1 1-32" and "bank 1 33-64" in the internal memory AND and factory cartridge set to bank #2 (ie. voices "bank 2 1-32" and "bank 2 33-64").
